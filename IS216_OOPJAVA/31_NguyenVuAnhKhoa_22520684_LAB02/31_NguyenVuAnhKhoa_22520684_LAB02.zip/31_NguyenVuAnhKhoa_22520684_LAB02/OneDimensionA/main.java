package com.oneDArray.models;

public class main {

	public static void main(String[] args) {
		 Menu.main(args);
	}

}
